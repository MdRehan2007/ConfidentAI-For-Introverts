
export type SkillId = string;

export enum LevelStatus {
  LOCKED = 'LOCKED',
  UNLOCKED = 'UNLOCKED',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED'
}

export type PracticePhase = 'idle' | 'preparing' | 'presenting' | 'questioning' | 'evaluating' | 'completed';

export interface Level {
  id: string;
  title: string;
  description: string;
  status: LevelStatus;
  type: 'presentation' | 'interview' | 'gd' | 'situational' | 'speech';
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Placement-Ready';
  duration: string;
  requirements?: string;
  needsUpload?: boolean;
}

export interface SubSkill {
  id: string;
  name: string;
  levels: Level[];
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  subSkills: SubSkill[];
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar: string;
  isAuthenticated: boolean;
  isAdmin: boolean;
  confidenceScore: number;
  readinessLevel: number;
  pendingEvaluations: Array<{
    id: string;
    skillName: string;
    levelTitle: string;
    timestamp: number;
    readyAt: number;
  }>;
}

export interface FeedbackData {
  clarity: number;
  confidence: number;
  fluency: number;
  eyeContact: number;
  vocabulary: number;
  readiness: number;
  summary: string;
  improvements: string[];
}
