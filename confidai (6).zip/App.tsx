
import React, { useState, useEffect } from 'react';
import { 
  Lock, Play, Mic2, Clock, Plus, Edit3, Settings
} from 'lucide-react';

import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import AuthModal from './components/AuthModal';
import PracticeSession from './components/PracticeSession';
import SettingsModal from './components/SettingsModal';
import { Category, SubSkill, Level, LevelStatus, UserProfile } from './types';
import { INITIAL_CATEGORIES, THEME } from './constants';

const HEAD_ADMIN_EMAIL = 'mhdrihan2007@gmail.com';

const App: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [activeSubSkill, setActiveSubSkill] = useState<SubSkill>(INITIAL_CATEGORIES[0].subSkills[0]);
  const [activeLevel, setActiveLevel] = useState<Level | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth > 1024);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  const [selectedCam, setSelectedCam] = useState('');
  const [selectedMic, setSelectedMic] = useState('');
  
  const [user, setUser] = useState<UserProfile>({
    id: 'guest',
    name: 'Guest User',
    email: 'guest@confidai.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ConfidAI',
    isAuthenticated: false,
    isAdmin: false,
    confidenceScore: 32,
    readinessLevel: 45,
    pendingEvaluations: []
  });

  const handleSubSkillSelect = (sub: SubSkill) => {
    if (!user.isAuthenticated) {
      setShowAuthModal(true);
      return;
    }
    setActiveSubSkill(sub);
    setActiveLevel(null);
  };

  const handleLevelClick = (level: Level) => {
    if (!user.isAuthenticated) {
      setShowAuthModal(true);
      return;
    }
    if (level.status === LevelStatus.LOCKED && !user.isAdmin) {
      alert("This level is locked. Reach the required performance in previous stages to unlock.");
      return;
    }
    setActiveLevel(level);
  };

  const handleLogin = (email: string) => {
    const isAdmin = email === HEAD_ADMIN_EMAIL;
    setUser({
      ...user,
      id: 'user_123',
      name: isAdmin ? 'Head Admin' : 'Active Learner',
      email: email,
      isAuthenticated: true,
      isAdmin: isAdmin
    });
    setShowAuthModal(false);
  };

  // When a level is active, it takes over the entire screen.
  if (activeLevel) {
    return (
      <div className="h-screen w-screen overflow-hidden bg-[#E8F9EE]">
        <PracticeSession 
          level={activeLevel} 
          skillName={activeSubSkill.name}
          selectedCamId={selectedCam}
          selectedMicId={selectedMic}
          onCancel={() => setActiveLevel(null)}
          onComplete={() => setActiveLevel(null)}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex transition-colors relative" style={{ backgroundColor: THEME.bgMain }}>
      <Sidebar 
        categories={categories} 
        activeSubSkillId={activeSubSkill.id} 
        onSubSkillSelect={handleSubSkillSelect}
        isOpen={isSidebarOpen}
      />

      <main className={`flex-1 flex flex-col transition-all duration-300 min-w-0 ${isSidebarOpen && window.innerWidth >= 1024 ? 'ml-[280px]' : 'ml-0'}`}>
        <TopBar 
          user={user} 
          title={activeSubSkill.name} 
          activeSubSkill={activeSubSkill}
          onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          onOpenSettings={() => setShowSettingsModal(true)}
          onLogout={() => {
            setUser({ ...user, isAuthenticated: false, isAdmin: false });
            setActiveLevel(null);
          }}
        />

        <div className="flex-1 mt-16 p-6 lg:p-10 overflow-y-auto custom-scrollbar text-black">
          <div className="max-w-7xl mx-auto space-y-12">
            <div className="flex flex-col md:flex-row justify-between items-end gap-6">
                <div>
                  <h2 className="text-4xl font-black italic tracking-tighter mb-2 text-black">Master: {activeSubSkill.name}</h2>
                  <p className="text-black/60 font-bold uppercase tracking-[0.3em] text-[10px]">Strategic Communication Path</p>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
                <div className="absolute top-1/2 left-0 right-0 h-1 bg-black/5 -translate-y-1/2 z-0 hidden lg:block" />
                {activeSubSkill.levels.map((lvl, idx) => {
                  const isLocked = lvl.status === LevelStatus.LOCKED && !user.isAdmin;
                  return (
                    <div 
                    key={lvl.id}
                    onClick={() => handleLevelClick(lvl)}
                    className={`group relative bg-white border-2 border-black/10 rounded-[40px] p-8 transition-all duration-500 cursor-pointer z-10 flex flex-col ${isLocked ? 'grayscale opacity-60' : 'hover:border-black hover:shadow-2xl hover:-translate-y-2'}`}
                    >
                      <div className="flex justify-between items-start mb-10">
                          <div className={`w-14 h-14 rounded-3xl flex items-center justify-center border-2 transition-colors ${isLocked ? 'border-black/5 bg-black/5 text-black/20' : 'border-black/10 bg-black/5 text-black group-hover:bg-black group-hover:text-white group-hover:border-black'}`}>
                            {isLocked ? <Lock className="w-6 h-6" /> : <Mic2 className="w-6 h-6" />}
                          </div>
                          <span className="text-[9px] font-black uppercase tracking-[0.2em] text-black/40">Step {idx + 1}</span>
                      </div>

                      <div className="flex-1 space-y-3">
                          <div className="flex items-center gap-2">
                            <span className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest ${lvl.difficulty === 'Placement-Ready' ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'}`}>
                              {lvl.difficulty}
                            </span>
                          </div>
                          <h4 className="text-xl font-black italic text-black transition-colors">{lvl.title}</h4>
                          <p className="text-xs text-black/60 font-medium leading-relaxed line-clamp-2">{lvl.description}</p>
                      </div>

                      <div className="mt-10 pt-6 border-t border-black/5 flex justify-between items-center">
                          <div className="flex items-center gap-2 text-[10px] font-bold text-black/40">
                            <Clock className="w-3 h-3" /> {lvl.duration}
                          </div>
                          {!isLocked && <Play className="w-4 h-4 text-black opacity-40 group-hover:opacity-100 transition-opacity" />}
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      </main>

      {showAuthModal && <AuthModal onLogin={handleLogin} onClose={() => setShowAuthModal(false)} />}
      {showSettingsModal && (
        <SettingsModal 
          selectedCam={selectedCam} 
          selectedMic={selectedMic}
          onCamChange={setSelectedCam}
          onMicChange={setSelectedMic}
          onClose={() => setShowSettingsModal(false)} 
        />
      )}
    </div>
  );
};

export default App;
