
import React, { useState } from 'react';
import { Search, Bell, Settings, LogOut, ChevronDown, Menu, User, FileText, Download, FileJson } from 'lucide-react';
import { UserProfile, SubSkill } from '../types';
import { THEME } from '../constants';

interface TopBarProps {
  user: UserProfile;
  title: string;
  activeSubSkill: SubSkill;
  onToggleSidebar: () => void;
  onLogout: () => void;
  onOpenSettings: () => void;
}

const TopBar: React.FC<TopBarProps> = ({ user, title, activeSubSkill, onToggleSidebar, onLogout, onOpenSettings }) => {
  const [showGuides, setShowGuides] = useState(false);

  const guides = [
    { level: 1, title: 'Foundation', format: '2-3 Sentences (20-30s)', color: 'bg-sky-600' },
    { level: 2, title: 'Structured', format: 'Greeting -> Bio -> Skill -> Goal (40-60s)', color: 'bg-emerald-600' },
    { level: 3, title: 'Mastery', format: 'Intro -> STAR Example -> Conclusion (1-2m)', color: 'bg-amber-600' },
    { level: 4, title: 'Elite', format: 'Natural Simulation & Interjection (2-4m)', color: 'bg-rose-600' }
  ];

  return (
    <header 
      className="fixed top-0 right-0 left-0 h-16 z-30 flex items-center justify-between px-6 border-b border-black/10 backdrop-blur-md"
      style={{ backgroundColor: `${THEME.bgMain}EE` }}
    >
      <div className="flex items-center gap-4">
        <button 
          onClick={onToggleSidebar}
          className="p-2 hover:bg-black/5 rounded-lg text-black"
        >
          <Menu className="w-5 h-5" />
        </button>
        <h2 className="text-lg font-black italic text-black tracking-tighter uppercase">{title}</h2>
      </div>

      <div className="flex items-center gap-4">
        {/* LEVEL FORMATS DROPDOWN */}
        <div className="relative">
          <button 
            onClick={() => setShowGuides(!showGuides)}
            className="flex items-center gap-2 px-4 py-2 bg-black/5 hover:bg-black/10 border border-black/5 rounded-xl transition-all"
          >
            <FileText className="w-4 h-4 text-black" />
            <span className="text-[10px] font-black text-black uppercase tracking-widest hidden lg:block">Level Formats</span>
            <ChevronDown className={`w-3 h-3 text-black/50 transition-transform ${showGuides ? 'rotate-180' : ''}`} />
          </button>

          {showGuides && (
            <div className="absolute top-full left-0 mt-2 w-72 bg-white border border-black/10 rounded-3xl shadow-2xl p-4 animate-in fade-in slide-in-from-top-2 duration-200">
              <p className="text-[10px] font-black text-black/50 uppercase tracking-widest mb-4 px-2">Study Guides: {activeSubSkill.name}</p>
              <div className="space-y-2">
                {guides.map(g => (
                  <div key={g.level} className="group p-3 hover:bg-black/5 rounded-2xl transition-all border border-transparent hover:border-black/5">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${g.color}`} />
                        <span className="text-[10px] font-black text-black uppercase italic">Level {g.level}</span>
                      </div>
                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button title="Download PDF" className="p-1 hover:text-sky-600"><FileText className="w-3 h-3 text-black" /></button>
                        <button title="Download TXT" className="p-1 hover:text-emerald-600"><Download className="w-3 h-3 text-black" /></button>
                      </div>
                    </div>
                    <p className="text-[10px] font-bold text-black/70 leading-tight">{g.format}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="hidden md:flex items-center bg-black/5 border border-black/5 rounded-full px-4 py-1.5 w-64">
          <Search className="w-4 h-4 text-black/50 mr-2" />
          <input 
            type="text" 
            placeholder="Search skills..." 
            className="bg-transparent border-none outline-none text-sm w-full text-black placeholder:text-black/30"
          />
        </div>

        <div className="flex items-center gap-3">
          <button onClick={onOpenSettings} className="p-2 text-black/60 hover:text-black transition-colors">
            <Settings className="w-5 h-5" />
          </button>
          <button className="relative p-2 text-black/60 hover:text-black transition-colors">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-white"></span>
          </button>
          
          <div className="h-8 w-px bg-black/10 mx-2"></div>

          <div className="group relative flex items-center gap-3 cursor-pointer">
            <img 
              src={user.avatar} 
              alt="Profile" 
              className="w-9 h-9 rounded-full ring-2 ring-black/5 group-hover:ring-black transition-all"
            />
            <div className="absolute right-0 top-full pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
              <div className="w-48 bg-white border border-black/10 rounded-xl shadow-2xl p-2 overflow-hidden">
                <button onClick={onLogout} className="w-full flex items-center gap-3 px-3 py-2 text-sm text-rose-600 hover:bg-rose-50 rounded-lg font-bold">
                  <LogOut className="w-4 h-4" /> Logout
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default TopBar;