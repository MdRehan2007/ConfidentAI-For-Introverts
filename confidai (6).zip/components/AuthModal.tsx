
import React, { useState } from 'react';
import { THEME } from '../constants';
import { X, Globe, Apple, Mail } from 'lucide-react';

interface AuthModalProps {
  onLogin: (email: string) => void;
  onClose?: () => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ onLogin, onClose }) => {
  const [email, setEmail] = useState('');

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" onClick={onClose}></div>
      
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-[40px] shadow-2xl overflow-hidden p-10 animate-in zoom-in-95 duration-300">
        {onClose && (
          <button onClick={onClose} className="absolute top-6 right-6 p-2 text-slate-500 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        )}

        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-sky-500 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-sky-500/20">
            <span className="text-3xl font-black text-slate-900 italic">C</span>
          </div>
          <h2 className="text-3xl font-black text-white mb-3 italic tracking-tighter">Enter ConfidAI</h2>
          <p className="text-slate-400 text-sm">Join the professional communication elite. Access AI-voice coaching and placement readiness.</p>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2">Simulate Login (Email)</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input 
                type="email" 
                placeholder="mhdrihan2007@gmail.com" 
                className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-white text-sm focus:border-sky-500 transition-all outline-none"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          <button 
            onClick={() => onLogin(email || 'user@example.com')}
            className="w-full bg-sky-500 hover:bg-sky-400 text-slate-900 font-black py-4 rounded-2xl transition-all shadow-xl shadow-sky-500/10 active:scale-95 uppercase text-xs tracking-widest"
          >
            Access Platform
          </button>
          
          <div className="flex items-center gap-4 my-6">
             <div className="h-px bg-slate-800 flex-1" />
             <span className="text-[10px] font-black text-slate-600 uppercase">Or</span>
             <div className="h-px bg-slate-800 flex-1" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 py-3 rounded-2xl transition-all text-white text-xs font-bold">
               <Globe className="w-4 h-4" /> Google
            </button>
            <button className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 py-3 rounded-2xl transition-all text-white text-xs font-bold">
               <Apple className="w-4 h-4" /> Apple
            </button>
          </div>
        </div>

        <div className="mt-10 text-center">
          <p className="text-[10px] text-slate-600 uppercase font-black tracking-widest">
            Privacy Guaranteed • 256-Bit Encryption
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
