
import React, { useState } from 'react';
import { Category, SubSkill } from '../types';
import { getIcon, THEME } from '../constants';
import { ChevronDown, ChevronRight, GraduationCap } from 'lucide-react';

interface SidebarProps {
  categories: Category[];
  activeSubSkillId: string;
  onSubSkillSelect: (sub: SubSkill) => void;
  isOpen: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ categories, activeSubSkillId, onSubSkillSelect, isOpen }) => {
  const [expandedCat, setExpandedCat] = useState<string | null>(categories[0].id);

  return (
    <aside 
      className={`fixed left-0 top-0 h-full z-40 transition-all duration-300 border-r border-black/5 flex flex-col shadow-xl overflow-hidden`}
      style={{ 
        width: isOpen ? '280px' : '0px', 
        backgroundColor: THEME.bgSidebar,
        transform: isOpen ? 'translateX(0)' : 'translateX(-100%)',
        visibility: isOpen ? 'visible' : 'hidden'
      }}
    >
      <div className="p-6 flex items-center gap-3 shrink-0">
        <div className="w-10 h-10 rounded-2xl flex items-center justify-center bg-black shadow-lg">
          <span className="font-black text-[#91C4A9] text-xl italic">C</span>
        </div>
        <h1 className="text-xl font-black tracking-tighter text-black italic uppercase">ConfidAI</h1>
      </div>

      <nav className="flex-1 overflow-y-auto px-4 py-2 space-y-1 custom-scrollbar">
        <p className="text-[10px] font-black text-black/60 uppercase tracking-[0.2em] mb-4 mt-2 px-3">Practice Roadmap</p>
        
        {categories.map((cat) => {
          const isExpanded = expandedCat === cat.id;
          return (
            <div key={cat.id} className="space-y-1">
              <button
                onClick={() => setExpandedCat(isExpanded ? null : cat.id)}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all ${
                  isExpanded ? 'text-black bg-black/10' : 'text-black/70 hover:bg-black/5'
                }`}
              >
                <div className="shrink-0">{getIcon(cat.icon, "w-5 h-5")}</div>
                <span className="flex-1 text-left text-[13px] font-black tracking-tight leading-none">{cat.name}</span>
                {isExpanded ? <ChevronDown className="w-4 h-4 text-black" /> : <ChevronRight className="w-4 h-4 text-black" />}
              </button>

              {isExpanded && (
                <div className="pl-6 space-y-1 mt-1 animate-in slide-in-from-left-2 duration-300">
                  {cat.subSkills.map(sub => (
                    <button
                      key={sub.id}
                      onClick={() => onSubSkillSelect(sub)}
                      className={`w-full text-left px-4 py-2.5 rounded-lg text-xs font-bold transition-all ${
                        activeSubSkillId === sub.id 
                          ? 'text-black bg-white/40 shadow-sm' 
                          : 'text-black/60 hover:text-black hover:bg-black/5'
                      }`}
                    >
                      {sub.name}
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      <div className="p-4 border-t border-black/10 bg-black/5">
        <div className="bg-white/20 p-4 rounded-2xl border border-black/5">
           <div className="flex justify-between text-[10px] font-black text-black/60 uppercase tracking-widest mb-2">Platform Rank</div>
           <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-black flex items-center justify-center text-[#91C4A9]"><GraduationCap className="w-4 h-4"/></div>
              <span className="text-xs font-black text-black italic uppercase">Silver Trainer</span>
           </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;