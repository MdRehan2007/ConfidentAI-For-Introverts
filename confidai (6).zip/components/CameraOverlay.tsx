
import React, { useState, useRef, useEffect } from 'react';
import { Camera, AlertCircle, RefreshCcw, Lock, RefreshCw, Mic } from 'lucide-react';

interface CameraOverlayProps {
  selectedCamId?: string;
  onStreamReady?: (stream: MediaStream) => void;
  onErrorStateChange?: (hasError: boolean) => void;
}

const CAM_SIZE = 240;

const CameraOverlay: React.FC<CameraOverlayProps> = ({
  selectedCamId,
  onStreamReady,
  onErrorStateChange
}) => {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [hwError, setHwError] = useState(false);
  const [permissionDenied, setPermissionDenied] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);
  const [isAudioOnly, setIsAudioOnly] = useState(false);
  const [position, setPosition] = useState({
    x: window.innerWidth - CAM_SIZE - 60,
    y: 60
  });
  const [isDragging, setIsDragging] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const dragStart = useRef({ x: 0, y: 0 });

  const initCamera = async (forceAudioOnly = false) => {
    if (isInitializing && !forceAudioOnly) return;
    
    setIsInitializing(true);
    setHwError(false);
    setPermissionDenied(false);
    onErrorStateChange?.(false);

    if (stream) {
      stream.getTracks().forEach(t => t.stop());
    }

    const constraints: MediaStreamConstraints = forceAudioOnly 
      ? { audio: true }
      : {
          video: selectedCamId ? { deviceId: { exact: selectedCamId } } : { width: { ideal: 640 }, height: { ideal: 480 } },
          audio: true
        };

    try {
      const finalStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(finalStream);
      onStreamReady?.(finalStream);
      
      const hasVideo = finalStream.getVideoTracks().length > 0;
      setIsAudioOnly(forceAudioOnly || !hasVideo);

      if (hasVideo) {
        // Fast-track video display
        setTimeout(() => {
          if (videoRef.current) {
            videoRef.current.srcObject = finalStream;
            videoRef.current.play().catch(err => {
              console.warn("Video play blocked:", err);
              // Retry on interaction if needed
            });
          }
        }, 50);
      }
    } catch (e: any) {
      console.warn("Hardware init failed:", e.name);
      
      // Immediate fallback chain
      if (!forceAudioOnly && (e.name === 'NotFoundError' || e.name === 'NotReadableError' || e.name === 'OverconstrainedError' || e.name === 'AbortError')) {
        return initCamera(true);
      }
      
      if (e.name === 'NotAllowedError' || e.name === 'PermissionDeniedError') {
        setPermissionDenied(true);
      } else {
        setHwError(true);
      }
      onErrorStateChange?.(true);
    } finally {
      setIsInitializing(false);
    }
  };

  useEffect(() => {
    initCamera();
    return () => {
      if (stream) stream.getTracks().forEach(track => track.stop());
    };
  }, [selectedCamId]);

  const onMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragStart.current = {
      x: e.clientX - position.x,
      y: e.clientY - position.y
    };
  };

  useEffect(() => {
    const move = (e: MouseEvent) => {
      if (!isDragging) return;
      setPosition({
        x: Math.max(0, Math.min(window.innerWidth - CAM_SIZE, e.clientX - dragStart.current.x)),
        y: Math.max(0, Math.min(window.innerHeight - CAM_SIZE, e.clientY - dragStart.current.y))
      });
    };
    const up = () => setIsDragging(false);
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    return () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
  }, [isDragging]);

  return (
    <>
      <div
        className="fixed z-[9999] cursor-grab active:cursor-grabbing"
        style={{ left: position.x, top: position.y, width: CAM_SIZE, height: CAM_SIZE }}
        onMouseDown={onMouseDown}
      >
        <div className={`w-full h-full rounded-full border-[8px] overflow-hidden relative shadow-4xl ${
          permissionDenied || hwError ? 'border-rose-500 bg-slate-900' : 'border-black bg-white'
        }`}>
          {isInitializing ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-emerald-50 text-emerald-600">
               <RefreshCw className="w-8 h-8 animate-spin mb-2" />
               <span className="text-[10px] font-black uppercase tracking-widest">Waking Hardware...</span>
            </div>
          ) : isAudioOnly ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-emerald-600 text-white p-4 text-center">
              <Mic className="w-10 h-10 mb-2 animate-pulse" />
              <p className="text-[10px] font-black uppercase tracking-widest">Voice Feed Only</p>
            </div>
          ) : stream ? (
            <video
              ref={videoRef}
              autoPlay
              muted
              playsInline
              className="w-full h-full object-cover mirror pointer-events-none"
            />
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center bg-slate-900">
              <Camera className="w-10 h-10 text-slate-500 mb-2" />
              <p className="text-[10px] font-black uppercase text-white/40 tracking-widest">Hardware Link</p>
            </div>
          )}
        </div>
      </div>

      {(hwError || permissionDenied) && (
        <div className="fixed inset-0 z-[1000] bg-white/95 backdrop-blur-2xl flex flex-col items-center justify-center p-12 animate-in fade-in duration-300">
          <div className="w-24 h-24 bg-rose-50 rounded-[32px] flex items-center justify-center mb-8 border border-rose-100 shadow-xl">
            <AlertCircle className="w-12 h-12 text-rose-500" />
          </div>
          <h2 className="text-5xl font-black italic uppercase tracking-tighter mb-4 text-black text-center">Sync Error</h2>
          <p className="text-black/60 text-center max-w-md font-bold text-lg mb-12 leading-relaxed">
            {permissionDenied 
              ? 'Site permissions are required to access your voice and camera for the professional simulation.' 
              : 'The platform could not detect a valid camera. Use Audio-Only mode to proceed without interruption.'}
          </p>
          <div className="flex gap-6">
            <button onClick={() => initCamera(false)} className="px-12 py-6 bg-black text-white rounded-[24px] font-black uppercase tracking-widest text-xs shadow-4xl hover:scale-105 transition-all">
               Retry Sync
            </button>
            <button onClick={() => initCamera(true)} className="px-12 py-6 border-4 border-black text-black rounded-[24px] font-black uppercase tracking-widest text-xs hover:bg-black hover:text-white transition-all">
               Force Voice Only
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default CameraOverlay;
