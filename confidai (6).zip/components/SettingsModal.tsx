
import React, { useState, useEffect } from 'react';
import { X, Camera, Mic, Settings, RefreshCcw, Check, AlertCircle } from 'lucide-react';

interface SettingsModalProps {
  onClose: () => void;
  selectedCam: string;
  selectedMic: string;
  onCamChange: (id: string) => void;
  onMicChange: (id: string) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ onClose, selectedCam, selectedMic, onCamChange, onMicChange }) => {
  const [cameras, setCameras] = useState<MediaDeviceInfo[]>([]);
  const [mics, setMics] = useState<MediaDeviceInfo[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refreshDevices = async () => {
    setIsRefreshing(true);
    setError(null);
    try {
      // Permission probe with fallbacks
      const probe = async () => {
        try { return await navigator.mediaDevices.getUserMedia({ audio: true, video: true }); } catch {
          try { return await navigator.mediaDevices.getUserMedia({ audio: true }); } catch {
            try { return await navigator.mediaDevices.getUserMedia({ video: true }); } catch {
              return null;
            }
          }
        }
      };

      const stream = await probe();
      if (stream) stream.getTracks().forEach(t => t.stop());

      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices.filter(d => d.kind === 'videoinput' && d.deviceId !== "");
      const audioDevices = devices.filter(d => d.kind === 'audioinput' && d.deviceId !== "");
      
      setCameras(videoDevices);
      setMics(audioDevices);

      if (videoDevices.length === 0 && audioDevices.length === 0) {
        setError("No audio or video hardware detected.");
      }

    } catch (e) {
      console.error("Device Refresh Error:", e);
      setError("Permission denied. Please check site settings.");
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    refreshDevices();
  }, []);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xl" onClick={onClose}></div>
      
      <div className="relative w-full max-w-xl bg-white border-2 border-black/5 rounded-[48px] shadow-4xl p-10 animate-in zoom-in-95 duration-300">
        <button onClick={onClose} className="absolute top-8 right-8 p-3 text-black/20 hover:text-black bg-black/5 rounded-full transition-colors">
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-6 mb-10">
          <div className="w-14 h-14 bg-black rounded-3xl flex items-center justify-center text-white shadow-xl">
            <Settings className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-3xl font-black text-black italic tracking-tighter uppercase">Hardware Hub</h2>
            <p className="text-black/40 text-xs font-bold uppercase tracking-widest">Configure your practice setup</p>
          </div>
        </div>

        {error && (
          <div className="mb-8 p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600 text-xs font-bold">
            <AlertCircle className="w-4 h-4 shrink-0" /> {error}
          </div>
        )}

        <div className="space-y-8">
          <div className="space-y-3">
            <div className="flex items-center justify-between px-2">
              <label className="text-[10px] font-black text-black/30 uppercase tracking-[0.2em] flex items-center gap-2">
                <Camera className="w-3 h-3" /> Visual Input
              </label>
              <button onClick={refreshDevices} disabled={isRefreshing} className="p-1 hover:text-black transition-colors">
                <RefreshCcw className={`w-3 h-3 ${isRefreshing ? 'animate-spin' : 'text-black/20'}`} />
              </button>
            </div>
            <select 
              className="w-full bg-black/5 border-2 border-black/5 rounded-2xl py-4 px-6 text-black text-xs font-black outline-none focus:border-black transition-all cursor-pointer"
              value={selectedCam}
              onChange={(e) => onCamChange(e.target.value)}
            >
              {cameras.length === 0 ? (
                <option value="">No Camera Found</option>
              ) : (
                cameras.map(cam => (
                  <option key={cam.deviceId} value={cam.deviceId}>{cam.label || `Default Camera`}</option>
                ))
              )}
            </select>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between px-2">
              <label className="text-[10px] font-black text-black/30 uppercase tracking-[0.2em] flex items-center gap-2">
                <Mic className="w-3 h-3" /> Audio Input
              </label>
            </div>
            <select 
              className="w-full bg-black/5 border-2 border-black/5 rounded-2xl py-4 px-6 text-black text-xs font-black outline-none focus:border-black transition-all cursor-pointer"
              value={selectedMic}
              onChange={(e) => onMicChange(e.target.value)}
            >
              {mics.length === 0 ? (
                <option value="">No Microphone Found</option>
              ) : (
                mics.map(mic => (
                  <option key={mic.deviceId} value={mic.deviceId}>{mic.label || `Default Mic`}</option>
                ))
              )}
            </select>
          </div>

          <div className="bg-emerald-50 border-2 border-black/5 p-6 rounded-[32px] flex gap-4">
             <div className="w-10 h-10 rounded-2xl bg-black flex items-center justify-center text-white shrink-0"><Check className="w-5 h-5" /></div>
             <div>
               <p className="text-black text-[10px] font-black uppercase tracking-widest mb-1">Fail-Safe Active</p>
               <p className="text-black/50 text-[10px] font-bold leading-relaxed">
                 ConfidAI will automatically switch to "Audio Practice" if your camera fails during a session.
               </p>
             </div>
          </div>

          <button 
            onClick={onClose}
            className="w-full bg-black text-white font-black py-5 rounded-3xl transition-all shadow-xl active:scale-95 uppercase text-[10px] tracking-[0.3em]"
          >
            Save Configuration
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
