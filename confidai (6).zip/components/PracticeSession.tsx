
import React, { useState, useRef, useEffect } from 'react';
import { 
  Check, Trophy, Clock, Signal, X, Play, Sparkles, AlertCircle, Timer
} from 'lucide-react';
import { Level, PracticePhase, FeedbackData } from '../types';
import { getNextAIAction, getSkillFeedback } from '../services/geminiService';
import CameraOverlay from './CameraOverlay';

interface PracticeSessionProps {
  level: Level;
  skillName: string;
  selectedCamId?: string;
  selectedMicId?: string;
  onComplete: (data: any) => void;
  onCancel: () => void;
}

const ASSISTANTS = {
  male: { name: 'Coach Marcus', img: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop', voiceName: 'Google US English' },
  female: { name: 'Coach Elena', img: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop', voiceName: 'Google UK English Female' }
};

type VocalStatus = "SILENT" | "VOICE DETECT" | "VOICE TOO LOW" | "TOO SLOW" | "NO MIC";

const PracticeSession: React.FC<PracticeSessionProps> = ({ 
  level, skillName, selectedCamId, selectedMicId, onComplete, onCancel 
}) => {
  const [phase, setPhase] = useState<PracticePhase | 'qa'>('idle');
  const [assistant, setAssistant] = useState<'male' | 'female'>('female');
  const [aiSpeech, setAiSpeech] = useState("");
  const [transcript, setTranscript] = useState("");
  const [conversationHistory, setHistory] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [vocalStatus, setVocalStatus] = useState<VocalStatus>("SILENT");
  const [finalFeedback, setFinalFeedback] = useState<FeedbackData | null>(null);
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  const [silenceCountdown, setSilenceCountdown] = useState(3);

  const lastSpeechTime = useRef<number>(Date.now());
  const currentTurnText = useRef<string>("");
  const analyserRef = useRef<AnalyserNode | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const totalSilenceStart = useRef<number>(Date.now());
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Warm up speech synthesis
    const loadVoices = () => window.speechSynthesis.getVoices();
    loadVoices();
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
    return () => window.speechSynthesis.cancel();
  }, []);

  useEffect(() => {
    if (phase === 'presenting' || phase === 'qa') {
      const t = setInterval(() => setSecondsElapsed(s => s + 1), 1000);
      return () => clearInterval(t);
    }
  }, [phase]);

  const speak = (text: string) => {
    if (!text) return;
    
    // Cancel any current speech
    window.speechSynthesis.cancel();
    
    // Immediately set speaking state to prevent nudge loop
    setIsSpeaking(true);
    setAiSpeech(text);

    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.05; 
    u.pitch = 1.0;
    
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.name.includes(ASSISTANTS[assistant].voiceName));
    u.voice = preferredVoice || voices[0];
    
    u.onend = () => {
      setIsSpeaking(false);
      setAiSpeech("");
      lastSpeechTime.current = Date.now();
      totalSilenceStart.current = Date.now();
      setSilenceCountdown(3);
    };

    u.onerror = (e) => {
      console.warn("Speech Synthesis Error", e);
      setIsSpeaking(false);
    };

    window.speechSynthesis.speak(u);
  };

  const handleAIAction = async (input: string, isQA: boolean = false) => {
    if (isThinking || isSpeaking) return;
    setIsThinking(true);
    
    if (!input.startsWith("System:")) {
      setTranscript(t => t + " " + input);
    }

    const hint = vocalStatus === "VOICE TOO LOW" ? "LOW VOLUME" : "";

    try {
      const res = await getNextAIAction(conversationHistory, input, skillName, false, isQA, hint);
      setHistory(h => h + `\nUser: ${input}\nAI: ${res.text}`);
      speak(res.text);
    } catch (err: any) {
      speak("I understand. What specifically drives your passion for " + skillName + "?");
    } finally {
      setIsThinking(false);
      totalSilenceStart.current = Date.now();
      setSilenceCountdown(3);
    }
  };

  const handleStreamReady = (stream: MediaStream) => {
    if (audioCtxRef.current) {
      audioCtxRef.current.close().catch(() => {});
    }

    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      audioCtxRef.current = ctx;
      analyserRef.current = analyser;
    } catch (e) {
      setVocalStatus("NO MIC");
    }

    // AI INITIATES SESSION
    if (phase === 'preparing') {
      setPhase('presenting');
      setTimeout(() => {
        handleAIAction(`System: Greet the user, introduce yourself as their coach, and challenge them to begin their ${skillName}. Be energetic.`);
      }, 300);
    }
  };

  useEffect(() => {
    if ((phase !== 'presenting' && phase !== 'qa') || isSpeaking || isThinking) return;
    
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';
    recognitionRef.current = recognition;

    recognition.onresult = (e: any) => {
      lastSpeechTime.current = Date.now();
      totalSilenceStart.current = Date.now();
      setSilenceCountdown(3);
      for (let i = e.resultIndex; i < e.results.length; ++i) {
        if (e.results[i].isFinal) {
          currentTurnText.current += " " + e.results[i][0].transcript;
        }
      }
    };

    recognition.onend = () => {
      if ((phase === 'presenting' || phase === 'qa') && !isSpeaking && !isThinking) {
        try { recognition.start(); } catch (e) {}
      }
    };

    try { recognition.start(); } catch (e) {}

    const monitorInterval = setInterval(() => {
      const now = Date.now();
      const totalSilenceDuration = now - totalSilenceStart.current;
      
      if (analyserRef.current) {
        const data = new Uint8Array(analyserRef.current.frequencyBinCount);
        analyserRef.current.getByteFrequencyData(data);
        const volume = data.reduce((a, b) => a + b, 0) / data.length;
        
        if (volume > 40) {
          lastSpeechTime.current = now;
          totalSilenceStart.current = now;
          setVocalStatus("VOICE DETECT");
        } else if (volume > 10) {
          setVocalStatus("VOICE TOO LOW");
        } else {
          setVocalStatus("SILENT");
        }
      }

      if (!isSpeaking && !isThinking) {
        const remaining = Math.max(0, 3 - Math.floor(totalSilenceDuration / 1000));
        setSilenceCountdown(remaining);

        // TRIGGER NUDGE IF SILENT FOR 3.2 SECONDS
        if (totalSilenceDuration > 3200) {
          const captured = currentTurnText.current.trim();
          currentTurnText.current = "";
          totalSilenceStart.current = now;
          
          const prompt = captured 
            ? captured 
            : `System: User silent for 3s. Ask a dynamic follow-up question related to ${skillName} (like a hobby or specific motivation) to restart the flow.`;
          
          handleAIAction(prompt, phase === 'qa');
        }
      }
    }, 100);

    return () => {
      clearInterval(monitorInterval);
      try { recognition.stop(); } catch (e) {}
    };
  }, [phase, isSpeaking, isThinking, skillName]);

  const handleFinish = async () => {
    setPhase('evaluating');
    try {
      const feedback = await getSkillFeedback(transcript, skillName, level.title);
      setFinalFeedback(feedback);
      setPhase('completed');
    } catch {
      setPhase('completed');
    }
  };

  if (phase === 'completed' && finalFeedback) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-[#E8F9EE]">
        <div className="max-w-4xl w-full bg-white border-2 border-black/10 p-12 rounded-[56px] shadow-2xl space-y-10 animate-in zoom-in duration-500">
           <div className="text-center">
              <Trophy className="w-16 h-16 mx-auto text-black mb-4" />
              <h2 className="text-4xl font-black italic uppercase tracking-tighter text-black">Audit Results</h2>
           </div>
           <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
             {Object.entries(finalFeedback).filter(([k]) => typeof finalFeedback[k as keyof FeedbackData] === 'number').map(([label, v]) => (
               <div key={label} className="bg-black/5 p-4 rounded-3xl text-center border border-black/5">
                  <p className="text-[8px] font-black text-black/50 uppercase mb-1">{label}</p>
                  <p className="text-xl font-black text-black">{v}/10</p>
               </div>
             ))}
           </div>
           <div className="p-8 bg-emerald-50 rounded-[40px] border-2 border-black/5">
              <h3 className="text-lg font-black italic text-black mb-2">Coach's Summary</h3>
              <p className="text-sm font-bold text-black/70 italic leading-relaxed">"{finalFeedback.summary}"</p>
           </div>
           <button onClick={onCancel} className="w-full py-5 bg-black text-white rounded-3xl font-black uppercase text-xs tracking-widest transition-all">Back to Dashboard</button>
        </div>
      </div>
    );
  }

  if (phase === 'idle') {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-[#E8F9EE] text-black">
        <button onClick={onCancel} className="absolute top-10 right-10 p-2 hover:bg-black/5 rounded-full z-50"><X className="w-6 h-6"/></button>
        <div className="max-w-4xl w-full bg-white p-12 rounded-[56px] border-2 border-black/5 shadow-2xl space-y-8">
            <div className="text-center space-y-4">
              <Sparkles className="w-12 h-12 mx-auto text-emerald-500" />
              <h2 className="text-5xl font-black italic tracking-tighter uppercase">{skillName}</h2>
              <p className="text-black/50 font-bold uppercase tracking-widest text-xs">{level.title}</p>
            </div>
            <div className="p-8 bg-black/5 rounded-[40px] border border-black/5 text-center text-xl font-bold text-black/70 italic leading-relaxed">
              "I'll start the conversation. If you pause for 3 seconds, I'll jump in to keep you on your toes!"
            </div>
            <div className="grid grid-cols-2 gap-4">
              {Object.entries(ASSISTANTS).map(([key, info]) => (
                <button key={key} onClick={() => setAssistant(key as any)} className={`p-6 rounded-[32px] border-2 transition-all flex items-center gap-4 ${assistant === key ? 'border-black bg-black/5' : 'border-black/5 hover:border-black/10'}`}>
                  <img src={info.img} className="w-14 h-14 rounded-full object-cover border-2 border-white" />
                  <div className="text-left">
                     <p className="text-sm font-black italic">{info.name}</p>
                     <p className="text-[8px] font-black uppercase text-black/40">Coach</p>
                  </div>
                </button>
              ))}
            </div>
            <button onClick={() => setPhase('preparing')} className="w-full py-8 bg-black text-white rounded-[32px] font-black uppercase tracking-widest text-sm shadow-2xl hover:scale-[1.02] transition-all">
              Start Professional Practice
            </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-[#E8F9EE] z-[500] flex flex-col overflow-hidden font-sans">
      {(phase === 'preparing' || phase === 'presenting' || phase === 'qa') && (
        <CameraOverlay selectedCamId={selectedCamId} onStreamReady={handleStreamReady} />
      )}

      <div className="absolute top-8 left-8 flex gap-5 z-50">
        <div className="bg-white rounded-[24px] px-8 py-5 shadow-2xl border border-black/5">
           <p className="text-[9px] font-black text-black/30 uppercase tracking-widest mb-1">Session Duration</p>
           <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-black" />
              <span className="text-3xl font-black font-mono text-black">
                {Math.floor(secondsElapsed/60)}:{(secondsElapsed%60).toString().padStart(2,'0')}
              </span>
           </div>
        </div>
        <div className="bg-white rounded-[24px] px-10 py-5 shadow-2xl border border-black/5">
           <p className="text-[9px] font-black text-black/30 uppercase tracking-widest mb-1">Nudge In</p>
           <div className="flex items-center gap-3">
              <Timer className={`w-5 h-5 ${silenceCountdown <= 1 ? 'text-rose-500 animate-pulse' : 'text-black'}`} />
              <span className={`text-3xl font-black font-mono ${silenceCountdown <= 1 ? 'text-rose-500' : 'text-black'}`}>
                {silenceCountdown}s
              </span>
           </div>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center relative p-10">
        <div className="relative">
            <div className={`w-[480px] h-[480px] rounded-full flex items-center justify-center transition-all duration-700 relative z-10 ${isSpeaking || isThinking ? 'scale-105 shadow-4xl' : ''}`}>
                <div className="absolute inset-0 rounded-full border-[2px] border-emerald-500/40"></div>
                <div className="w-[440px] h-[440px] rounded-full overflow-hidden shadow-4xl bg-white border-4 border-white">
                    <img src={ASSISTANTS[assistant].img} className={`w-full h-full object-cover transition-all duration-700 ${isSpeaking || isThinking ? 'opacity-100 scale-100' : 'opacity-40 grayscale scale-110'}`} alt="Coach" />
                </div>
                {(isSpeaking || isThinking) && (
                    <div className="absolute inset-[-20px] rounded-full border-[8px] border-emerald-500 border-t-transparent animate-spin duration-[1000ms]"></div>
                )}
            </div>

            {aiSpeech && (
                <div className="absolute top-1/2 left-full ml-16 -translate-y-1/2 w-[480px] bg-white p-12 rounded-[56px] shadow-4xl border-2 border-black/10 z-20 animate-in slide-in-from-left-4 duration-300">
                    <p className="text-3xl font-black italic text-black leading-tight uppercase tracking-tighter">"{aiSpeech}"</p>
                </div>
            )}
        </div>
      </div>

      <div className="px-12 pb-12 w-full flex justify-center mt-auto">
        <div className="w-full max-w-7xl h-40 bg-white rounded-[60px] flex items-center justify-between px-20 shadow-4xl border border-black/10">
           <div className="flex flex-col">
              <p className="text-[12px] font-black text-black/30 uppercase tracking-[0.3em] mb-1">Coach Status</p>
              <p className="text-5xl font-black text-emerald-600 italic uppercase tracking-tighter leading-none">
                {isSpeaking ? 'Speaking...' : isThinking ? 'Analyzing...' : 'Watching You'}
              </p>
           </div>
           <button onClick={handleFinish} className="bg-black text-white px-20 h-20 rounded-[30px] font-black uppercase tracking-[0.2em] shadow-4xl text-sm hover:bg-emerald-800 transition-colors active:scale-95">
              <Check className="w-5 h-5 mr-4 inline" /> Finish & Audit
           </button>
           <div className="flex items-center gap-10 text-right">
              <div>
                 <p className="text-[12px] font-black text-black/30 uppercase tracking-[0.3em] mb-1">Vocal Output</p>
                 <p className={`text-2xl font-black italic uppercase tracking-tighter ${vocalStatus === 'VOICE TOO LOW' ? 'text-rose-500' : 'text-black'}`}>{vocalStatus}</p>
              </div>
              <Signal className={`w-12 h-12 ${vocalStatus === 'VOICE DETECT' ? 'text-emerald-500 animate-pulse' : 'text-black/10'}`} />
           </div>
        </div>
      </div>
    </div>
  );
};

export default PracticeSession;
