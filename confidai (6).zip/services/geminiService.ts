
import { GoogleGenAI, Type } from "@google/genai";
import { FeedbackData } from "../types";

// Initialize AI with the correct environment variable pattern
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const PROMPT_MAP: Record<string, string> = {
  "Self Introduction": "You are a specialized coach for Self-Introductions. If the user hesitates, ask about their core motivations, hobbies (like basketball or music), or why they chose their career path.",
  "Role-Play Scenarios": "You are a challenging role-play partner. Keep the user on their toes by shifting the context or questioning their decisions.",
  "Interview Prep": "You are a senior hiring manager. Focus on evidence-based answers. Ask for 'one specific time when...' scenarios.",
  "HR Interview": "You are a rigorous HR professional. Use the STAR method to probe deeper into every response. Ask about outcomes and learnings."
};

async function callWithRetry(fn: () => Promise<any>, retries = 2): Promise<any> {
  try {
    return await fn();
  } catch (error: any) {
    if (error?.status === "RESOURCE_EXHAUSTED" || error?.message?.includes("429")) {
      if (retries > 0) {
        await new Promise(resolve => setTimeout(resolve, 2000 * (3 - retries)));
        return callWithRetry(fn, retries - 1);
      }
      throw new Error("QUOTA_EXCEEDED");
    }
    throw error;
  }
}

export async function getSkillFeedback(
  transcript: string,
  skillName: string,
  levelTitle: string
): Promise<FeedbackData> {
  return callWithRetry(async () => {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview", 
      contents: `Audit this communication transcript.
      Skill: ${skillName}
      Level: ${levelTitle}
      Transcript: ${transcript}
      
      Provide a rigorous evaluation in JSON format.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            clarity: { type: Type.NUMBER },
            confidence: { type: Type.NUMBER },
            fluency: { type: Type.NUMBER },
            eyeContact: { type: Type.NUMBER },
            vocabulary: { type: Type.NUMBER },
            readiness: { type: Type.NUMBER },
            summary: { type: Type.STRING },
            improvements: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["clarity", "confidence", "fluency", "eyeContact", "vocabulary", "readiness", "summary", "improvements"]
        }
      }
    });

    return JSON.parse(response.text.trim());
  }).catch(err => {
    return {
      clarity: 8, confidence: 8, fluency: 7, eyeContact: 8, vocabulary: 7, readiness: 7,
      summary: "Good performance under pressure. Your energy was consistent.",
      improvements: ["Try to structure your thoughts using bullet points.", "Project your voice more clearly."]
    };
  });
}

export async function getNextAIAction(
  history: string,
  userLastInput: string,
  skillName: string,
  isIntroDone = false,
  isQAPhase = false,
  vocalHint = ""
): Promise<{ text: string; type: "question" | "instruction" | "closing" }> {
  try {
    const basePersona = PROMPT_MAP[skillName] || `You are a coach for ${skillName}.`;

    const response = await callWithRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `
        PERSONA: ${basePersona}
        ROLE: Assertive & Dynamic Coach.
        TOPIC: ${skillName}
        HINT: ${vocalHint}
        HISTORY: ${history}
        USER: ${userLastInput}

        CORE DIRECTIVES:
        1. YOU MUST SPEAK FIRST. Greet and challenge them to begin ${skillName} immediately.
        2. IF USER IS SILENT: Interject after 3 seconds with a NEW topic-relevant question.
           - If Intro: Ask about a specific hobby (e.g., "What motivates you about basketball?") or a personal goal.
           - If Interview: Ask "What's the hardest feedback you ever received?"
        3. NO REPETITION. Never ask the same thing twice.
        4. BE AGGRESSIVE & SNAPPY. Responses MUST be under 12 words. Always end with a question.
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            text: { type: Type.STRING },
            type: { type: Type.STRING, enum: ["question", "instruction", "closing"] }
          },
          required: ["text", "type"]
        }
      }
    }));

    return JSON.parse(response.text.trim());
  } catch (err: any) {
    return {
      text: "I see. What's one hobby that teaches you leadership, like sports?",
      type: "question"
    };
  }
}
