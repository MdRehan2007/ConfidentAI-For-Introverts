
import React from 'react';
import { 
  User, MessageSquare, Users, Mic2, Presentation, BookOpen, Smile, 
  ShieldCheck, Briefcase, BrainCircuit, Target, Sparkles, 
  Lightbulb, ShieldAlert, Globe, Zap, GraduationCap, RefreshCcw, Landmark, Trophy, Fingerprint, HeartHandshake,
  Stethoscope, Scale, Rocket, Network, Brain, FileText, Languages, HelpCircle
} from 'lucide-react';
import { Category, LevelStatus, Level } from './types';

export const THEME = {
  bgMain: '#E8F9EE',    // Pale Mint from Image
  bgSidebar: '#91C4A9', // Sage Green from Image
  bgCard: '#FFFFFF',
  accent: '#1A202C',    // Black/Dark Slate for contrast
  success: '#059669',   // Deep Emerald
  warning: '#DC2626',   // Red
  amber: '#D97706'      // Dark Amber
};

const createLevels = (type: any, baseTitle: string): Level[] => [
  { 
    id: `l1-${baseTitle.replace(/\s+/g, '-')}-${Math.random().toString(36).substr(2, 9)}`, 
    title: `Level 1: ${baseTitle} - Foundations`, 
    description: 'Learn core terminology and basic structuring of thoughts.', 
    status: LevelStatus.UNLOCKED, 
    type, 
    difficulty: 'Beginner', 
    duration: '5m' 
  },
  { 
    id: `l2-${baseTitle.replace(/\s+/g, '-')}-${Math.random().toString(36).substr(2, 9)}`, 
    title: `Level 2: ${baseTitle} - Development`, 
    description: 'Focus on vocal variety, eye contact, and smooth transitions.', 
    status: LevelStatus.LOCKED, 
    type, 
    difficulty: 'Intermediate', 
    duration: '12m' 
  },
  { 
    id: `l3-${baseTitle.replace(/\s+/g, '-')}-${Math.random().toString(36).substr(2, 9)}`, 
    title: `Level 3: ${baseTitle} - Mastery`, 
    description: 'Handle complex logic defense and rapid follow-up challenges.', 
    status: LevelStatus.LOCKED, 
    type, 
    difficulty: 'Advanced', 
    duration: '20m' 
  },
  { 
    id: `l4-${baseTitle.replace(/\s+/g, '-')}-${Math.random().toString(36).substr(2, 9)}`, 
    title: `Level 4: ${baseTitle} - Elite Performance`, 
    description: 'Full simulation with high-integrity AI stress testing.', 
    status: LevelStatus.LOCKED, 
    type, 
    difficulty: 'Placement-Ready', 
    duration: '30m' 
  }
];

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'cat-1', name: '1. Communication Skills', icon: 'Mic2',
    subSkills: [
      { id: 'ss-1', name: 'Self Introduction', levels: createLevels('interview', 'Self Intro') },
      { id: 'ss-2', name: 'College Introduction', levels: createLevels('speech', 'College Intro') },
      { id: 'ss-3', name: 'Professional Introduction', levels: createLevels('interview', 'Work Intro') },
      { id: 'ss-4', name: 'Interview Introduction', levels: createLevels('interview', 'Pitch Intro') },
      { id: 'ss-5', name: 'Personal Branding', levels: createLevels('speech', 'Brand Pitch') },
      { id: 'ss-6', name: 'Spoken English', levels: createLevels('speech', 'Conversational English') }
    ]
  },
  {
    id: 'cat-2', name: '2. Presentation & Speaking', icon: 'Presentation',
    subSkills: [
      { id: 'ss-7', name: 'PPT Presentation', levels: createLevels('presentation', 'Slide Flow') },
      { id: 'ss-8', name: 'Public Speaking', levels: createLevels('speech', 'Stage Presence') },
      { id: 'ss-9', name: 'Body Language', levels: createLevels('situational', 'Postural Impact') }
    ]
  },
  {
    id: 'cat-3', name: '3. Interview Prep', icon: 'MessageSquare',
    subSkills: [
      { id: 'ss-10', name: 'HR Interview', levels: createLevels('interview', 'Behavioral Round') },
      { id: 'ss-11', name: 'Technical Interview', levels: createLevels('interview', 'Logic Verbalization') },
      { id: 'ss-12', name: 'Managerial Round', levels: createLevels('interview', 'Strategy Sync') }
    ]
  },
  {
    id: 'cat-4', name: '4. Group Discussion', icon: 'Users',
    subSkills: [
      { id: 'ss-13', name: 'GD Basics', levels: createLevels('gd', 'Initiation') },
      { id: 'ss-14', name: 'Advanced GD', levels: createLevels('gd', 'Polite Disagreement') },
      { id: 'ss-15', name: 'Leadership in GD', levels: createLevels('gd', 'Team Guidance') }
    ]
  },
  {
    id: 'cat-5', name: '5. Emotional Control', icon: 'Smile',
    subSkills: [
      { id: 'ss-16', name: 'Confidence Building', levels: createLevels('speech', 'Hesitation Removal') },
      { id: 'ss-17', name: 'Anxiety Control', levels: createLevels('situational', 'Stress Response') },
      { id: 'ss-18', name: 'Self-Awareness', levels: createLevels('speech', 'Weakness Mapping') }
    ]
  },
  {
    id: 'cat-6', name: '6. Professional Workplace', icon: 'Briefcase',
    subSkills: [
      { id: 'ss-19', name: 'Corporate Comms', levels: createLevels('situational', 'Meeting Etiquette') },
      { id: 'ss-20', name: 'Formal Language', levels: createLevels('speech', 'Professional Tone') },
      { id: 'ss-21', name: 'Client Interaction', levels: createLevels('situational', 'Value Explaining') }
    ]
  },
  {
    id: 'cat-7', name: '7. Situational Practice', icon: 'Target',
    subSkills: [
      { id: 'ss-22', name: 'Situational Judgment', levels: createLevels('situational', 'Workplace Ethics') },
      { id: 'ss-23', name: 'Role-Play Scenarios', levels: createLevels('situational', 'Managerial Role') }
    ]
  },
  {
    id: 'cat-8', name: '8. AI Practice Modes', icon: 'BrainCircuit',
    subSkills: [
      { id: 'ss-24', name: 'AI Voice Practice', levels: createLevels('speech', '1-on-1 AI Coach') },
      { id: 'ss-25', name: 'AI Interview Mode', levels: createLevels('interview', 'AI HR Sim') },
      { id: 'ss-26', name: 'AI GD Mode', levels: createLevels('gd', 'Multi-Participant AI') }
    ]
  },
  {
    id: 'cat-9', name: '9. Placement Readiness', icon: 'GraduationCap',
    subSkills: [
      { id: 'ss-27', name: 'Placement GD', levels: createLevels('gd', 'Final Mock GD') },
      { id: 'ss-28', name: 'Professional Readiness', levels: createLevels('interview', 'Mock Assessment') }
    ]
  },
  {
    id: 'cat-10', name: '10. Thinking & Expression', icon: 'Lightbulb',
    subSkills: [
      { id: 'ss-29', name: 'Critical Thinking', levels: createLevels('speech', 'Logical Thought Flow') },
      { id: 'ss-30', name: 'Analytical Speaking', levels: createLevels('speech', 'Data Interpretation') }
    ]
  },
  {
    id: 'cat-11', name: '11. Problem-Solving', icon: 'Zap',
    subSkills: [
      { id: 'ss-31', name: 'Problem Explanation', levels: createLevels('speech', 'Step-by-Step Clarity') },
      { id: 'ss-32', name: 'Solution Defense', levels: createLevels('speech', 'Approach Justification') }
    ]
  },
  {
    id: 'cat-12', name: '12. Leadership & Influence', icon: 'Trophy',
    subSkills: [
      { id: 'ss-33', name: 'Motivating Others', levels: createLevels('speech', 'Visionary Speech') },
      { id: 'ss-34', name: 'Persuasion Skills', levels: createLevels('speech', 'Stakeholder Buy-in') }
    ]
  },
  {
    id: 'cat-13', name: '13. Workplace Soft Skills', icon: 'HeartHandshake',
    subSkills: [
      { id: 'ss-35', name: 'Team Conflict', levels: createLevels('situational', 'Conflict Resolution') },
      { id: 'ss-36', name: 'Giving Feedback', levels: createLevels('situational', 'Constructive Tone') }
    ]
  },
  {
    id: 'cat-14', name: '14. Customer Interaction', icon: 'Users',
    subSkills: [
      { id: 'ss-37', name: 'Customer Support', levels: createLevels('situational', 'Empathy Speaking') },
      { id: 'ss-38', name: 'Sales Pitching', levels: createLevels('speech', 'Product Demo') }
    ]
  },
  {
    id: 'cat-15', name: '15. Global Communication', icon: 'Globe',
    subSkills: [
      { id: 'ss-39', name: 'Cross-Cultural Sensitivity', levels: createLevels('speech', 'Global Etiquette') },
      { id: 'ss-40', name: 'Remote Meeting Mastery', levels: createLevels('situational', 'Virtual Presentation') }
    ]
  },
  {
    id: 'cat-16', name: '16. Stress & Pressure', icon: 'ShieldAlert',
    subSkills: [
      { id: 'ss-41', name: 'Rapid Response', levels: createLevels('speech', 'Under Pressure Talk') },
      { id: 'ss-42', name: 'Crisis Comms', levels: createLevels('situational', 'Emergency Explaining') }
    ]
  },
  {
    id: 'cat-17', name: '17. Language Expansion', icon: 'Languages',
    subSkills: [
      { id: 'ss-43', name: 'Advanced Vocabulary', levels: createLevels('speech', 'Industry Terms') },
      { id: 'ss-44', name: 'Paraphrasing', levels: createLevels('speech', 'Idea Refinement') }
    ]
  },
  {
    id: 'cat-18', name: '18. Ethics & Judgment', icon: 'ShieldCheck',
    subSkills: [
      { id: 'ss-45', name: 'Ethical Dilemmas', levels: createLevels('interview', 'Value Justification') },
      { id: 'ss-46', name: 'Corporate Integrity', levels: createLevels('speech', 'Professional Morality') }
    ]
  },
  {
    id: 'cat-19', name: '19. Career Branding', icon: 'Network',
    subSkills: [
      { id: 'ss-47', name: 'Elevator Pitch', levels: createLevels('speech', '60-Second USP') },
      { id: 'ss-48', name: 'Networking Comm', levels: createLevels('situational', 'B2B Interaction') }
    ]
  },
  {
    id: 'cat-20', name: '20. Tech Communication', icon: 'Sparkles',
    subSkills: [
      { id: 'ss-49', name: 'Simplifying Tech', levels: createLevels('speech', 'Non-Tech Explanation') },
      { id: 'ss-50', name: 'AI System Interaction', levels: createLevels('speech', 'Prompt-Based Thinking') }
    ]
  },
  {
    id: 'cat-21', name: '21. Mock Assessment', icon: 'Target',
    subSkills: [
      { id: 'ss-51', name: 'Timed Certification', levels: createLevels('interview', 'Final Certification') }
    ]
  },
  {
    id: 'cat-22', name: '22. Reflection & Self-Growth', icon: 'RefreshCcw',
    subSkills: [
      { id: 'ss-52', name: 'Self-Reflection Talk', levels: createLevels('speech', 'Outcome Analysis') },
      { id: 'ss-53', name: 'Goal Setting Comm', levels: createLevels('speech', 'Future Career Planning') }
    ]
  }
];

export const getIcon = (iconName: string, className?: string) => {
  const finalClass = className ? `${className} text-black` : 'text-black';
  switch (iconName) {
    case 'Mic2': return <Mic2 className={finalClass} />;
    case 'Presentation': return <Presentation className={finalClass} />;
    case 'MessageSquare': return <MessageSquare className={finalClass} />;
    case 'Users': return <Users className={finalClass} />;
    case 'Smile': return <Smile className={finalClass} />;
    case 'Briefcase': return <Briefcase className={finalClass} />;
    case 'Trophy': return <Trophy className={finalClass} />;
    case 'ShieldAlert': return <ShieldAlert className={finalClass} />;
    case 'Globe': return <Globe className={finalClass} />;
    case 'Lightbulb': return <Lightbulb className={finalClass} />;
    case 'Target': return <Target className={finalClass} />;
    case 'BrainCircuit': return <BrainCircuit className={finalClass} />;
    case 'Sparkles': return <Sparkles className={finalClass} />;
    case 'Landmark': return <Landmark className={finalClass} />;
    case 'Fingerprint': return <Fingerprint className={finalClass} />;
    case 'HeartHandshake': return <HeartHandshake className={finalClass} />;
    case 'Languages': return <Languages className={finalClass} />;
    case 'ShieldCheck': return <ShieldCheck className={finalClass} />;
    case 'Network': return <Network className={finalClass} />;
    case 'RefreshCcw': return <RefreshCcw className={finalClass} />;
    case 'GraduationCap': return <GraduationCap className={finalClass} />;
    case 'Zap': return <Zap className={finalClass} />;
    default: return <HelpCircle className={finalClass} />;
  }
};